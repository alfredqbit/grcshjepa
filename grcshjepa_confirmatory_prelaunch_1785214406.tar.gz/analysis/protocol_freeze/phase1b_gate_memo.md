# Phase 1B Gate Memo for Confirmatory Protocol v1.1

Written at UTC: 2026-07-28T04:53:24.007317+00:00

Phase 1B was a remediation and launch-gate phase, not a confirmatory study. It passed the noncollapse, frozen-backbone downstream-head, and routing-coupling gates. Its seeds and metrics are excluded from confirmatory inference.

No hyperparameter tuning may occur after this memo except to correct a documented code defect before launch, in which case the protocol version must be incremented.
