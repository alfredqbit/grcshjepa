
from __future__ import annotations
import argparse, hashlib, json, platform, subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def save_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

def save_yaml(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")

def load_yaml(path):
    return yaml.safe_load(Path(path).read_text(encoding="utf-8"))

def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def git_commit_hash():
    try:
        return subprocess.check_output(["git","rev-parse","HEAD"], text=True).strip()
    except Exception:
        return "unknown"

def git_status_porcelain():
    try:
        return subprocess.check_output(["git","status","--porcelain"], text=True).strip()
    except Exception:
        return "unknown"

def protocol_v11_dict():
    return {
        "protocol_id": "GR-CS-HJEPA-CONFIRMATORY-V1.1",
        "frozen_at_utc": utc_now(),
        "launch_status": "launchable_after_clean_prelaunch_dry_run",
        "phase1b_status_required": "launchable_confirmatory_ready",
        "primary_experimental_unit": "independently initialized and trained model seed",
        "pilot_exclusion_rule": "Exclude Phase 0, Phase 1, Phase 1B, and administrative dry-run seeds from confirmatory inference.",
        "failure_rule": "Model-dependent failures remain in primary analysis; administrative hardware failures are rerun under the same seed and documented.",
        "multiplicity": "Holm control over primary hypotheses; FDR for secondary diagnostics.",
        "analysis_lock": "Run analysis once on blinded variant labels before unblinding.",
        "phase1b_selected_defaults": {
            "train_n": 768, "val_n": 256, "test_n": 256, "batch_size": 64,
            "latent_dim": 64, "projection_dim": 32, "hidden_dim": 128,
            "pretraining_epochs": 14, "downstream_head_epochs": 25,
            "learning_rate": 2e-3, "head_learning_rate": 2e-3,
            "weight_decay": 1e-4, "ema_tau": 0.995,
            "lambda_ac": 0.50, "variance_floor_gamma": 0.70, "lambda_var": 2.0,
            "low_shot_fraction_primary": 0.30,
            "secondary_label_fractions": [0.10, 0.20, 0.50, 1.00],
            "max_horizon": 4
        },
        "phase1b_gate_summary": {
            "n_complete": 6, "n_failed": 0,
            "mean_effective_rank_min": 25.1288,
            "mean_cov_trace_min": 15.7580,
            "mean_ac_loss_max": 0.3731,
            "mean_maze_action_accuracy": 0.5870,
            "mean_maze_majority_baseline": 0.5250,
            "mean_sorting_mse": 0.0120,
            "mean_sorting_exactish_rate": 0.0593,
            "mean_routing_random_damage_drop": 0.0598,
            "mean_routing_coupled_to_model": 1.0,
            "launch_status": "launchable_confirmatory_ready"
        },
        "launch_gates": {
            "G0_tests": "All unit tests and administrative dry-runs pass on a clean runtime.",
            "G1_noncollapse": "effective rank >= 6.0, covariance trace >= 1.0, anti-collapse loss <= 8.0",
            "G2_downstream_heads": "maze action accuracy > max(0.35, majority+0.02); sorting MSE <= 0.12 or exactish >= 0.05",
            "G3_routing": "finite metrics, positive damage drop, learned-model-coupled route loads",
            "G4_protocol": "configs, seeds, endpoints, failure rules, runtime/container info, and scripts have frozen hashes"
        },
        "confirmatory_studies": {
            "study1_predictive_pretraining": {
                "script": "scripts/run_confirmatory_study1.py",
                "seed_list": list(range(1000,1016)),
                "primary_variants": ["GR-CS-HJEPA-spiking","flat-HJEPA-MLP"],
                "primary_endpoint": "held-out normalized latent prediction error subject to noncollapse gates",
                "margin": 0.02
            },
            "study2_low_shot_downstream_heads": {
                "script": "scripts/run_confirmatory_study2.py",
                "seed_list": list(range(2000,2016)),
                "primary_variants": ["GR-CS-HJEPA-spiking-30pct-head","flat-HJEPA-MLP-30pct-head"],
                "primary_endpoint": "frozen-backbone downstream performance at 30 percent labels"
            },
            "study3_routing_damage": {
                "script": "scripts/run_confirmatory_study3.py",
                "seed_list": list(range(3000,3020)),
                "primary_variants": ["full-routing-surface","euclidean-length-control","matched-sparsity-control","no-geometry-control"],
                "primary_endpoint": "damage-induced degradation and surface-normalized predictive quality"
            }
        }
    }

def write_protocol(path):
    protocol = protocol_v11_dict()
    save_yaml(path, protocol)
    return protocol

def validate_expected_launch_plan(protocol_path):
    protocol = load_yaml(protocol_path)
    counts = {k: len(v["seed_list"]) for k, v in protocol["confirmatory_studies"].items()}
    total = sum(counts.values())
    return {"counts": counts, "total": total, "expected_total": 52, "ok": total == 52 and sorted(counts.values()) == [16,16,20]}

def write_phase1b_gate_memo(out_dir):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    path = out / "phase1b_gate_memo.md"
    text = (
        "# Phase 1B Gate Memo for Confirmatory Protocol v1.1\n\n"
        f"Written at UTC: {utc_now()}\n\n"
        "Phase 1B was a remediation and launch-gate phase, not a confirmatory study. "
        "It passed the noncollapse, frozen-backbone downstream-head, and routing-coupling gates. "
        "Its seeds and metrics are excluded from confirmatory inference.\n\n"
        "No hyperparameter tuning may occur after this memo except to correct a documented code defect before launch, "
        "in which case the protocol version must be incremented.\n"
    )
    path.write_text(text, encoding="utf-8")
    return path

def write_freeze_record(protocol_path, out_dir):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    files = []
    for root in ["configs","scripts","src","tests","analysis"]:
        if Path(root).exists():
            files.extend([p for p in Path(root).rglob("*") if p.is_file() and "__pycache__" not in str(p)])
    record = {
        "written_at_utc": utc_now(),
        "git_commit": git_commit_hash(),
        "git_status_porcelain": git_status_porcelain(),
        "protocol_path": str(protocol_path),
        "protocol_hash": sha256_file(protocol_path),
        "file_hashes": {str(p): sha256_file(p) for p in sorted(set(files))},
        "python": platform.python_version(),
        "platform": platform.platform()
    }
    save_json(out / "confirmatory_protocol_v1_1_hash_record.json", record)
    return record

def write_administrative_dry_run(study, seed, protocol_path, output_dir):
    protocol = load_yaml(protocol_path)
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    manifest = {
        "status": "administrative_dry_run_complete",
        "study": study,
        "seed": seed,
        "protocol_id": protocol["protocol_id"],
        "protocol_hash": sha256_file(protocol_path),
        "git_commit": git_commit_hash(),
        "written_at_utc": utc_now(),
        "confirmatory_inference_eligible": False,
        "reason_not_eligible": "Administrative dry-run seed; no scientific metric.",
        "python": platform.python_version(),
        "platform": platform.platform()
    }
    save_json(out / "manifest.json", manifest)
    save_json(out / "metrics.json", {"status": "dry_run_no_scientific_metrics", "study": study, "seed": seed, "all_primary_metrics": None})
    save_json(out / "environment.json", {"python": platform.python_version(), "platform": platform.platform(), "git_commit": git_commit_hash(), "time_utc": utc_now()})
    (out / "checkpoint.DRYRUN.txt").write_text("Administrative dry-run: no model checkpoint.\n", encoding="utf-8")
    return manifest

def launch_commands(protocol_path, base_output_dir="runs/confirmatory"):
    protocol = load_yaml(protocol_path)
    cmds = []
    for study, spec in protocol["confirmatory_studies"].items():
        for seed in spec["seed_list"]:
            cmds.append(f"python {spec['script']} --protocol {protocol_path} --seed {seed} --output-dir {base_output_dir}/{study}/seed_{seed} --execute")
    return cmds

def write_launch_plan(protocol_path, out_dir):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    cmds = launch_commands(protocol_path)
    plan = {
        "status": "ready_after_commit_tag_and_dry_run_review",
        "protocol_path": str(protocol_path),
        "protocol_hash": sha256_file(protocol_path),
        "n_commands": len(cmds),
        "commands": cmds,
        "warning": "Do not execute until production runners and frozen hashes are approved."
    }
    save_json(out / "confirmatory_launch_plan.json", plan)
    (out / "confirmatory_launch_plan.sh").write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + "\n".join(cmds) + "\n", encoding="utf-8")
    return plan

def cli_confirmatory_study(study, argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if args.dry_run:
        print(json.dumps(write_administrative_dry_run(study, args.seed, args.protocol, args.output_dir), indent=2))
        return
    if args.execute:
        try:
            from grcshjepa.confirmatory.production import run_confirmatory_study
        except Exception as exc:
            raise SystemExit("Production runner missing. Implement grcshjepa.confirmatory.production.run_confirmatory_study and rerun prelaunch dry-runs before executing confirmatory seeds.") from exc
        print(json.dumps(run_confirmatory_study(study=study, seed=args.seed, protocol_path=args.protocol, output_dir=args.output_dir), indent=2, default=str))
        return
    raise SystemExit("Use --dry-run or --execute.")
