from grcshjepa.confirmatory_prelaunch import protocol_v11_dict, save_yaml, validate_expected_launch_plan, write_administrative_dry_run, write_launch_plan

def test_protocol_seed_counts(tmp_path):
    p=tmp_path/"protocol.yaml"; save_yaml(p, protocol_v11_dict()); v=validate_expected_launch_plan(p); assert v["ok"] and v["total"]==52

def test_dry_run_manifest(tmp_path):
    p=tmp_path/"protocol.yaml"; save_yaml(p, protocol_v11_dict()); m=write_administrative_dry_run("study1_predictive_pretraining",999001,p,tmp_path/"dry"); assert m["status"]=="administrative_dry_run_complete" and not m["confirmatory_inference_eligible"]

def test_launch_plan(tmp_path):
    p=tmp_path/"protocol.yaml"; save_yaml(p, protocol_v11_dict()); plan=write_launch_plan(p,tmp_path/"out"); assert plan["n_commands"]==52
