from grcshjepa.confirmatory_prelaunch import cli_confirmatory_study
if __name__ == "__main__":
    cli_confirmatory_study("study2_low_shot_downstream_heads")
