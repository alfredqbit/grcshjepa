import argparse, json
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument("--runs-dir", required=True); ap.add_argument("--out", required=True); a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True, exist_ok=True); manifests=sorted(Path(a.runs_dir).rglob("manifest.json")) if Path(a.runs_dir).exists() else []; payload={"status":"aggregation_scaffold","n_manifests":len(manifests),"manifests":[str(p) for p in manifests]}; (out/"aggregation_manifest.json").write_text(json.dumps(payload, indent=2)); print(json.dumps(payload, indent=2))
