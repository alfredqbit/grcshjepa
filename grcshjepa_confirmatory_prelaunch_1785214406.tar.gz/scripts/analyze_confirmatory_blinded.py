import argparse, json
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument("--input", required=True); ap.add_argument("--out", required=True); a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True, exist_ok=True); payload={"status":"blinded_analysis_scaffold","input":a.input,"instruction":"Replace with locked statistical analysis before unblinding."}; (out/"blinded_analysis_manifest.json").write_text(json.dumps(payload, indent=2)); print(json.dumps(payload, indent=2))
