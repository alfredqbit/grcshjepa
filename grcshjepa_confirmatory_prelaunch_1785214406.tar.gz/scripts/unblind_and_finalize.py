raise SystemExit("Unblinding disabled in scaffold. Enable only after blinded QC and committee-approved protocol lock.")
